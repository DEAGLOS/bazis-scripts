@echo off
REM Перетащи .obj файл на этот .bat — он сам вызовет python и создаст .js
REM рядом с исходным .obj. Должен лежать в той же папке, что obj_to_bazis.py

if "%~1"=="" (
    echo Перетащи .obj файл на этот bat-файл.
    pause
    exit /b
)

python "%~dp0obj_to_bazis.py" "%~1"
echo.
pause
